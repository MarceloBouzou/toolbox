// app/generador-contraseñas/page.tsx
export default function GeneradorContrasenasPage() {
  return (
    <main className="p-8">
      <h1 className="text-3xl font-bold">Generador de Contraseñas Seguras</h1>
      <p className="mt-4">Esta herramienta está en construcción.</p>
    </main>
  );
}