// app/validar-json/page.tsx
export default function ValidarJsonPage() {
  return (
    <main className="p-8">
      <h1 className="text-3xl font-bold">Formateador y Validador JSON</h1>
      <p className="mt-4">Esta herramienta está en construcción.</p>
    </main>
  );
}